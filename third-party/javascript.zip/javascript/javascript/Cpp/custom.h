// Enable this macro definition when compiled to a static library
// #define ANTLR4CPP_STATIC

// TODO: add some include