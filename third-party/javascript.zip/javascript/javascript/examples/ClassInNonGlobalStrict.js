// Check whether static members are parsed inside a class
// without explicit strict mode.
class ClassWithoutExplicitStrictMode {
    static myStaticMethod() {}
}
