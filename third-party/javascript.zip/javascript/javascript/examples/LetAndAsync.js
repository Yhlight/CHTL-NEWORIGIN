let foo = 123;
var let = 123;

var async = 456;

"use strict";
var let = 123;