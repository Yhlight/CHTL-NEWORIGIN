var sql = "line 1 \
	some other line \
the last line"