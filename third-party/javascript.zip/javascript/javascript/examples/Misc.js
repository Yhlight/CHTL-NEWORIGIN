var e\u0065e;
var e\u{0065}e; // var eee;

var Π;
// var 全世界无产者联合起来; //UTF8
var \u4e00;

0b0n;
12345n;
0x1234n;
12_123;
1.123_3456e-7_8
0b0_1n;

try {}
catch{}
finally{}

try {}
finally{}

2**3*5;

async function process(array) {
  for await (let i of array) {
    doSomething(i);
  }
}

const {a, ...c} = obj;
const obj2 = { ...obj1, z: 26 ,...obj2};
const [aa,b,...ca] = aarr;
const v = [asdf,...gh,jk];
var f = [,,c,...a,b,,];
var g = [,,]; // [undefined,undefined]

function f([asdfg]=12345){}
/* TODO:
function async (proc, ...params) {}
var async = 1;*/

const a = { duration: 50 };
a.duration ??= 10;