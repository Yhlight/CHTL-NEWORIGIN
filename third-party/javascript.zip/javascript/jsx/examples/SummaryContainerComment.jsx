import React from 'react';
class SummaryContainer extends React.Component {
    render() {
        return (
            <div>Content：<a target="_blank" href="https://www.github.com">https://www.github.com</a>
            </div>
        );
    }
}
