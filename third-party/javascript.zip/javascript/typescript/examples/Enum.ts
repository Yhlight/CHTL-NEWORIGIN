enum Colors {
  Red = "RED",
  Green = "GREEN",
  Blue = "BLUE"
}
