namespace StringUtility
{
    function ToCapital(str: string): string {
        return str.toUpperCase();
    }

    function Nemw(str: string, length: number = 0): string {
        return str.toUpperCase();
    }
    export function Eported(from: string, length: number = 0): string {
        return from.toUpperCase();
    }

    export function Eported2(str: string, length: number = 0): string {
        return str.toUpperCase();
    }
}

export type MyType = {
    field: number;
    field2: string;
}
