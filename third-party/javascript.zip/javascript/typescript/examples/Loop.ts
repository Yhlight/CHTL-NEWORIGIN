let object = {};
for (let field in object) {
};

let array = [];
for (let element of array) {
};

for (let element: number of array) {
};

for await (const document of array) {

};

for await (const document: string of array) {

};

for (let [field, value] of Object.entries(object) as [string, any]) {

};